(function() {
	$(document).ready(function() {
		$(".button-collapse").sideNav();
		$('.parallax').parallax();
	});
})();
